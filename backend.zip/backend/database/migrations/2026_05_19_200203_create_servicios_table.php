<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('servicios', function (Blueprint $table) {
            $table->id();
            $table->string('nombre');
            $table->decimal('precio', 8, 2);
            $table->string('icono')->default('fa-solid fa-wrench');
            $table->string('extra_nota')->nullable();
            $table->string('categoria'); // 'moviles', 'consolas', 'ordenadores'
            $table->timestamps();
        });
    }
    public function down(): void
    {
        Schema::dropIfExists('servicios');
    }
};
